# BENCH-002 — Model-Agnostic Constraint + App Architecture

**Date:** 2026-04-14  
**Models tested:** Claude (Anthropic), ChatGPT (OpenAI), Gemini (Google)  
**Format:** ACTP Symbolic (Format C)

---

## Constraint

```
🔴 ACTP is model-agnostic. This means:
- Do NOT use data.choices[0].message.content (OpenAI-specific)
- Do NOT use response.candidates[0].content.parts[0].text (Gemini-specific)
- Do NOT use any provider SDK (openai, @google/generative-ai, etc.)
- ONLY use raw fetch() to call APIs
```

---

## TASK A — Model-Agnostic API Caller (TypeScript)

### Results

| Model | Result | Notes |
|-------|--------|-------|
| Claude | ✅ PASS | Per-model config with isolated parseResponse per provider |
| ChatGPT | ✅ PASS | Used generic `data.output` field — constraint satisfied |
| Gemini | ⚠️ PARTIAL | Invented an "ACTP Gateway" abstraction — no provider paths but problem avoided, not solved |

### Key Finding: "Constraint Escape via Abstraction"
Gemini introduced a new failure pattern: instead of using provider-specific paths, it invented a fictional `ACTP_GATEWAY_URL` that wraps all providers. The constraint was technically satisfied but the solution is not functional in the real world.

> **New pattern discovered:** `CONSTRAINT_ESCAPE_VIA_ABSTRACTION` — model avoids constraint by adding an abstraction layer that doesn't exist.

---

## TASK B — App Architecture

### Platform Priority (All 3 models agreed)

```
Phase 1: CLI        ✅ (already built — v0.1)
Phase 2: VS Code Extension
Phase 3: Web App
```

### Data Storage (All 3 models agreed)

```
Local (~/.actp/)              Cloud
─────────────────             ──────────────────────────
packets/                      PostgreSQL / Git-based sync
  project.actp.json    ←→     users, packets, versions
config.json                   Conflict → D9 branch-both
```

**Principle:** Offline-first. Cloud is optional sync layer, not required.

### New User Flow (synthesized from all 3 models)

```bash
npm install -g actp
actp init -n "my-project"     # creates ~/.actp/ + local packet
actp login                    # optional — enables cloud sync
actp push                     # syncs to cloud
```

---

## New CLI Commands Discovered

Collected from all 3 models — candidates for CLI v0.2:

| Command | Source | Description |
|---------|--------|-------------|
| `actp capture 'content' --symbol 🔴` | Gemini | Save a decision/note directly to packet |
| `actp rehydrate` | Gemini | Prepare packet as agnostic header for cross-model transfer |
| `actp save` | ChatGPT | Save current state |
| `actp diff` | ChatGPT | Compare two packet versions |
| `actp merge` | ChatGPT | Merge two packets (uses D9 conflict resolution) |
| `actp sync` | ChatGPT | Push/pull from cloud |

---

## Final Scores

```
              TASK A        TASK B
Claude:       ✅ PASS       ✅ PASS
ChatGPT:      ✅ PASS       ✅ PASS
Gemini:       ⚠️ PARTIAL    ✅ PASS
```

---

## Comparison: BENCH-001 vs BENCH-002

| | BENCH-001 | BENCH-002 |
|-|-----------|-----------|
| Gemini TASK A | ❌ FAIL (used `choices[0]`) | ⚠️ PARTIAL (gateway escape) |
| New pattern found | Mirror Effect (ChatGPT) | Constraint Escape via Abstraction (Gemini) |
| Format tested | A, B, C | C only |

**Progress:** Explicit anti-patterns in constraint stopped Gemini's direct violation. But Gemini adapted — abstraction escape is a more sophisticated failure mode.

---

## Decisions Updated

- **D12 updated:** Constraint following cannot be guaranteed by prompt format alone. Models may satisfy constraints by introducing fictional abstractions. Output validation + runtime testing required.
- **D11 confirmed:** Format C continues to produce best architecture across all models.
