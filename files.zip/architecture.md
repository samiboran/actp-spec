# ACTP — Application Architecture

**Version:** 0.2-draft  
**Decision source:** BENCH-002 (Claude + ChatGPT + Gemini consensus)

---

## Platform Roadmap

```
Phase 1 — CLI (✅ v0.1 complete)
Phase 2 — VS Code Extension
Phase 3 — Web App (actp.dev)
```

All 3 models agreed on this order. CLI is developer-first, fastest MVP,
no UI complexity, easy schema iteration.

---

## Data Architecture

### Local (offline-first)

```
~/.actp/
  config.json
  packets/
    <project-name>/
      current.actp.json
      versions/
        v1.actp.json
        v2.actp.json
```

- Works fully offline
- No account required for local use
- Human-readable JSON at all times ("No hidden state" — ChatGPT)

### Cloud (optional sync)

```
actp.dev (PostgreSQL)
  users
    id, email, identity_key, created_at
  packets
    id, user_id, project_name, content, created_at
  versions
    id, packet_id, version, content, message, created_at
```

- Cloud is opt-in — `actp login` enables it
- Conflict resolution: D9 branch-both + vector clocks
- P0 tie → human-in-the-loop, no silent auto-merge

### Sync Flow

```
Local change detected
        ↓
actp sync --push
        ↓
Cloud checks vector clock
        ↓
No conflict → merge     Conflict → branch-both → human prompt
        ↓
Cloud updated
```

---

## New User Onboarding

```bash
# Step 1 — Install
npm install -g actp

# Step 2 — Initialize project
actp init -n "my-project" -g "Build X" -m "claude"
# Creates: ~/.actp/packets/my-project/current.actp.json

# Step 3 — Capture first decision
actp capture "Use fetch() only, no SDKs" --symbol 🔴

# Step 4 — Save snapshot
actp save --message "Initial setup"

# Step 5 (optional) — Enable cloud sync
actp login
actp sync --push

# Step 6 — Transfer to another model
actp rehydrate
# Outputs: formatted prompt header → paste into Claude/ChatGPT/Gemini
```

---

## Phase 2 — VS Code Extension

**Why second:**
- Developer already working there
- Context can be captured automatically (file saves, decisions)
- "Save context" button in sidebar

**Features planned:**
- Sidebar panel: current packet summary
- Auto-capture on file save (optional)
- `Rehydrate` button → copies prompt to clipboard
- Packet version timeline view

---

## Phase 3 — Web App (actp.dev)

**Why last:**
- Broadest audience but most complex
- Requires cloud backend to be stable first

**Features planned:**
- Dashboard: all projects + packet history
- Shareable packet links
- Diff viewer (visual)
- Maestro: send to Claude + ChatGPT + Gemini simultaneously

---

## UX Philosophy (ChatGPT contribution)

> "File-based workflow. Transparent JSON. No hidden state. AI optional layer."

ACTP is not an AI chat interface.  
ACTP is an AI workflow state manager.

---

## Cloud Backend Stack (proposed)

```
API:      Node.js + Express (or Hono)
DB:       PostgreSQL
Auth:     JWT + API key
Hosting:  Railway / Fly.io (phase 3)
```
