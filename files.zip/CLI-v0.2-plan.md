# CLI v0.2 — Implementation Plan

**Current:** v0.1 — init, validate, summary  
**Target:** v0.2 — capture, rehydrate, save, diff, merge, sync

---

## New Commands

### `actp capture`
```bash
actp capture "We decided to use fetch() only" --symbol 🔴
```
- Appends a new decision to the current packet
- `--symbol` sets priority (🔴 P0, 🟡 P1, 🔵 P2)
- Source: Gemini BENCH-002

### `actp rehydrate`
```bash
actp rehydrate ./context.actp.json
```
- Reads packet and outputs a formatted prompt header
- Ready to paste into any AI model (Claude, ChatGPT, Gemini)
- Source: Gemini BENCH-002

### `actp save`
```bash
actp save --message "Added benchmark results"
```
- Saves current state with a commit message
- Creates versioned snapshot in ~/.actp/packets/
- Source: ChatGPT BENCH-002

### `actp diff`
```bash
actp diff v0.1 v0.2
```
- Compares two packet versions
- Shows added/removed/changed fields
- Source: ChatGPT BENCH-002

### `actp merge`
```bash
actp merge packet-a.actp.json packet-b.actp.json
```
- Merges two packets using D9 conflict resolution
- P0 tie → prompts human-in-the-loop
- Source: ChatGPT BENCH-002

### `actp sync`
```bash
actp sync          # push + pull
actp sync --push   # push only
actp sync --pull   # pull only
```
- Syncs local ~/.actp/ with cloud
- Requires: actp login
- Source: ChatGPT BENCH-002

---

## Implementation Order

```
Priority  Command     Complexity   Dependency
────────────────────────────────────────────
P0        capture     LOW          packet.ts
P0        rehydrate   LOW          packet.ts
P1        save        MEDIUM       fs + versioning
P1        diff        MEDIUM       save
P2        sync        HIGH         cloud backend
P2        merge       HIGH         diff + D9 logic
```

---

## File Changes Required

### `cli/src/types.ts`
- Add `ACTPVersion` interface
- Add `SyncConfig` interface

### `cli/src/packet.ts`
- Add `captureDecision(symbol, content)`
- Add `rehydratePacket(packet)` → returns prompt string
- Add `saveVersion(packet, message)`
- Add `diffPackets(a, b)`

### `cli/src/index.ts`
- Register new commands: capture, rehydrate, save, diff, merge, sync

---

## Local Storage Structure (v0.2)

```
~/.actp/
  config.json              # user config, cloud credentials
  packets/
    my-project/
      current.actp.json    # active packet
      versions/
        v1.actp.json
        v2.actp.json
```
